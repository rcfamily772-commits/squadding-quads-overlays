SQ Pack Lottery v1.1
Copy WIDGETS/SQLotto to your radio SD card WIDGETS folder. Restart, assign SQLotto in Screen Settings and open full screen.
Four levels: Beginner, Intermediate, Advanced and OnlyDrones. OnlyDrones has one challenge, Just Fly, with 12 rotating messages. Fly only when safe and legal.
Field preview: physical radio testing remains open.
