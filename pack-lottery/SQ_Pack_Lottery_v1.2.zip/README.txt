SQ Pack Lottery v1.2
Copy WIDGETS/SQLotto to your radio SD card WIDGETS folder, replacing the previous main.lua. Restart, assign SQLotto in Screen Settings and open full screen.
Five levels: Beginner, Intermediate, Advanced, OnlyDrones and Bench Pilot. Each of the two comedy decks has one challenge with 12 rotating messages. Complete your safety checks and fly only when safe and legal.
Field preview: physical radio testing remains open.
